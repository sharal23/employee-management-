package boppo.exam.springboot.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import boppo.exam.springboot.dto.UserRegistrationDto;
import boppo.exam.springboot.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
